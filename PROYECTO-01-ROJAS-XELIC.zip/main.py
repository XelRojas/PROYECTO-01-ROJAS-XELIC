from lifestore_file import lifestore_products
from lifestore_file import lifestore_sales
from lifestore_file import lifestore_searches

#LOGIN-------
import getpass
usuario_admin = ("Kokun")
password = ("123")

def login(usuario,passw):
  if usuario in usuario_admin:
    if passw in password:
        return 1
    else:
      print("\n\tLa contraseña no coincide con el usuario.\n")
  else:
      return 2
 
usuario=input("Usuario: ")
passw = getpass.getpass("Password: ")

if login(usuario,passw)==2:
  print("\tEl usuario no está registrado o no se permite el acceso.")

elif login(usuario,passw)==1:
  print("\n\t¡BIENVENIDO! " + usuario)

  print ("\nINFORMACIÓN DISPONIBLE")
  print ("\n1. Productos con mayores ventas.", "\n2. Productos con mayores búsquedas.", "\n3. Productos con menores ventas por categoría.", "\n4. Productos con menores búsquedas por categoría. \n5. Productos con mejores reseñas.", "\n6. Productos con peores reseñas.", )

  respuesta=input ("\n¿Qué desea ver? (Ingrese el número correspondiente): ")

#PRODUCTOS CON MAYORES VENTAS
  contador= 0 #nos permite repetir
  frecuencia_ventas = [] #lista vacía donde se guardará datos
#Contar las veces que se repite
  if respuesta =="1":

    for producto in lifestore_products:
      for venta in lifestore_sales:
        if producto[0] == venta[1]:
          contador +=1

      ventas = [producto[0], contador]
      frecuencia_ventas.append(ventas)
      contador =0
#print(frecuencia_ventas)
#La lista: frecuencia_ventas contiene ID + Veces que se repite.
#ORDENAR DE MAYOR A MENOR  
    mayores_ventas=[]

    while frecuencia_ventas:
      maximo = frecuencia_ventas[0][1] 
      lista_actual = frecuencia_ventas[0]
      for ventas in frecuencia_ventas:
        if ventas[1]> maximo:
          maximo = ventas[1]
          lista_actual = ventas
      mayores_ventas.append(lista_actual)
      frecuencia_ventas.remove(lista_actual)

#print(mayores_ventas)
#La lista: mayores_ventas contiene ID + ventas ordenadas de mayor a menor.

    
    print ("\n\t50 PRODUCTOS CON MAYORES VENTAS\n") 
#IMPRIMIR NOMBRE 
    contador_dos =0
    nombre_id=[]

    for id_producto in mayores_ventas:
      for nombre_producto in    lifestore_products:
        if id_producto[0] == nombre_producto[0]:
          nombres = [nombre_producto[1],id_producto[0]]
          nombre_id.append(nombres)

    for indice in range(0,50):
      print ("~",nombre_id[indice][0])

#PRODUCTOS CON MAYORES BÚSQUEDAS

  frecuencia_busquedas =[]
  contador = 0
  if respuesta =="2":
  
    for producto_1 in lifestore_products:
      for busqueda in lifestore_searches:
        if producto_1[0] == busqueda[1]:
          contador +=1
          
      busquedas = [producto_1[0], contador]
      frecuencia_busquedas.append(busquedas)
      contador =0

#print(frecuencia_ventas)
#La lista: frecuencia_busquedas contiene ID + Veces que se repite.
#ORDENAR DE MAYOR A MENOR  
    mayores_busquedas=[]

    while frecuencia_busquedas:
      maximo = frecuencia_busquedas[0][1] 
      lista_actual_2 = frecuencia_busquedas[0]
      for busquedas in frecuencia_busquedas:
        if busquedas[1]> maximo:
          maximo = busquedas[1]
          lista_actual_2 = busquedas
      mayores_busquedas.append(lista_actual_2)
      frecuencia_busquedas.remove(lista_actual_2)

  #La lista: mayores_busquedas contiene ID + busquedas ordenadas de mayor a menor.
    print ("\n\t50 PRODUCTOS CON MAYORES BUSQUEDAS\n") 

    

  #IMPRIMIR NOMBRE 
    contador_tres =0
    busqueda_id=[]

    for id_producto in mayores_busquedas:
      for nombre_producto in lifestore_products:
        if id_producto[0] == nombre_producto[0]:
          nombres = [nombre_producto[1],id_producto[0]]
          busqueda_id.append(nombres)

    for indice_2 in range(0,50):
      print ("~",busqueda_id[indice_2][0])

#MENORES VENTAS POR CATEGORÍA

  categorias=["procesadores", "tarjetas de video", "tarjetas madre", "discos duros", "memorias usb", "pantallas", "bocinas", "audifonos"]
  if respuesta == "3":
    for producto in lifestore_products:
      for venta in lifestore_sales:
        if producto[0] == venta[1]:
          contador +=1

      ventas = [producto[0], contador,producto[3]]
      frecuencia_ventas.append(ventas)
      contador =0

#print(frecuencia_ventas)
#La lista: frecuencia_ventas contiene ID + Veces que se repite + categoría

#ORDENAR DE MENOR A MAYOR 
    menores_ventas=[]

    while frecuencia_ventas:
      minimo = frecuencia_ventas[0][1] 
      lista_actual = frecuencia_ventas[0]
      for ventas in frecuencia_ventas:
        if ventas[1]< minimo:
          minimo = ventas[1]
          lista_actual = ventas
      menores_ventas.append(lista_actual)
      frecuencia_ventas.remove(lista_actual)
  
#La lista: menores_ventas contiene ID + ventas ordenadas de mayor a menor + categoría
    print ("\n\tPRODUCTOS CON MENORES VENTAS\n") 
#IMPRIMIR NOMBRE 
    contador_dos =0
    nombre_id=[]
    nombre_id_1=[]
    nombre_id_2=[]
    nombre_id_3=[]
    nombre_id_4=[]
    nombre_id_5=[]
    nombre_id_6=[]
    nombre_id_7=[]

    for id_producto in menores_ventas:
      for nombre_producto in lifestore_products:
        if id_producto[0] == nombre_producto[0] and id_producto[2] ==  categorias[0]:
          nombres = [nombre_producto[1],id_producto[0],id_producto[2]]
          nombre_id.append(nombres)
    
    print("\nPara la categoría de: ", categorias[0],"\n")

    for indice in range(0,7):
      print ("~",nombre_id[indice][0]) 


    for id_producto_1 in menores_ventas:
      for nombre_producto_1 in lifestore_products:
        if id_producto_1[0] == nombre_producto_1[0] and id_producto_1[2] ==  categorias[1]:
          nombres = [nombre_producto_1[1],id_producto_1[0],id_producto_1[2]]
          nombre_id_1.append(nombres)

    print("\nPara la categoría de: ", categorias[1],"\n")

    for indice in range(0,7):
      print ("~",nombre_id_1[indice][0]) 


    for id_producto_2 in menores_ventas:
      for nombre_producto_2 in lifestore_products:
        if id_producto_2[0] == nombre_producto_2[0] and id_producto_2[2] ==  categorias[2]:
          nombres = [nombre_producto_2[1],id_producto_2[0],id_producto_2[2]]
          nombre_id_2.append(nombres)

    print("\nPara la categoría de: ", categorias[2],"\n")

    for indice in range(0,7):
      print ("~",nombre_id_2[indice][0]) 

    for id_producto_3 in menores_ventas:
      for nombre_producto_3 in lifestore_products:
        if id_producto_3[0] == nombre_producto_3[0] and id_producto_3[2] ==  categorias[3]:
          nombres = [nombre_producto_3[1],id_producto_3[0],id_producto_3[2]]
          nombre_id_3.append(nombres)

    print("\nPara la categoría de: ", categorias[3],"\n")

    for indice in range(0,7):
      print ("~",nombre_id_3[indice][0])  

    for id_producto_4 in menores_ventas:
      for nombre_producto_4 in lifestore_products:
        if id_producto_4[0] == nombre_producto_4[0] and id_producto_4[2] ==  categorias[4]:
          nombres = [nombre_producto_4[1],id_producto_4[0],id_producto_4[2]]
          nombre_id_4.append(nombres)

    print("\nPara la categoría de: ", categorias[4],"\n")

    for indice in range(0,2):
      print ("~",nombre_id_4[indice][0])  

    
    for id_producto_5 in menores_ventas:
      for nombre_producto_5 in lifestore_products:
        if id_producto_5[0] == nombre_producto_5[0] and id_producto_5[2] ==  categorias[5]:
          nombres = [nombre_producto_5[1],id_producto_5[0],id_producto_5[2]]
          nombre_id_5.append(nombres)

    print("\nPara la categoría de: ", categorias[5],"\n")

    for indice in range(0,7):
      print ("~",nombre_id_5[indice][0]) 

    for id_producto_6 in menores_ventas:
      for nombre_producto_6 in lifestore_products:
        if id_producto_6[0] == nombre_producto_6[0] and id_producto_6[2] ==  categorias[6]:
          nombres = [nombre_producto_6[1],id_producto_6[0],id_producto_6[2]]
          nombre_id_6.append(nombres)

    print("\nPara la categoría de: ", categorias[6],"\n")

    for indice in range(0,7):
      print ("~",nombre_id_6[indice][0])

    for id_producto_7 in menores_ventas:
      for nombre_producto_7 in lifestore_products:
        if id_producto_7[0] == nombre_producto_7[0] and id_producto_7[2] ==  categorias[7]:
          nombres = [nombre_producto_7[1],id_producto_7[0],id_producto_7[2]]
          nombre_id_7.append(nombres)

    print("\nPara la categoría de: ", categorias[7],"\n")

    for indice in range(0,7):
      print ("~",nombre_id_7[indice][0])


#MENORES BUSQUEDASS POR CATEGORÍA
  categorias=["procesadores", "tarjetas de video", "tarjetas madre", "discos duros", "memorias usb", "pantallas", "bocinas", "audifonos"]
  frecuencia_busquedas =[]
  contador = 0
  if respuesta =="4":
  
    for producto_1 in lifestore_products:
      for busqueda in lifestore_searches:
        if producto_1[0] == busqueda[1]:
          contador +=1
          
      busquedas = [producto_1[0], contador, producto_1[3]]
      frecuencia_busquedas.append(busquedas)
      contador =0

#print(frecuencia_busquedas)
#La lista: frecuencia_busquedas contiene ID + Veces que se repite + Categoría.

#ORDENAR DE MENOR A MAYOR 
    menores_busquedas=[]

    while frecuencia_busquedas:
      minimo = frecuencia_busquedas[0][1] 
      lista_actual_2 = frecuencia_busquedas[0]
      for busquedas in frecuencia_busquedas:
        if busquedas[1]< minimo:
          minimo = busquedas[1]
          lista_actual_2 = busquedas
      menores_busquedas.append(lista_actual_2)
      frecuencia_busquedas.remove(lista_actual_2)

  #La lista: mayores_busquedas contiene ID + busquedas ordenadas de mayor a menor.
    print ("\n\tPRODUCTOS CON MENORES BUSQUEDAS\n") 

  #IMPRIMIR NOMBRE 
    contador_tres =0
    busqueda_id=[]
    busqueda_id_1=[]
    busqueda_id_2=[]
    busqueda_id_3=[]
    busqueda_id_4=[]
    busqueda_id_5=[]
    busqueda_id_6=[]
    busqueda_id_7=[]

    for id_producto in menores_busquedas:
      for nombre_producto in lifestore_products:
        if id_producto[0] == nombre_producto[0] and id_producto[2] == categorias[0]:
          nombres = [nombre_producto[1],id_producto[0]]
          busqueda_id.append(nombres)

    print("\nPara la categoría de: ", categorias[0],"\n")

    for indice_2 in range(0,7):
      print ("~",busqueda_id[indice_2][0])

    for id_producto_1 in menores_busquedas:
      for nombre_producto_1 in lifestore_products:
        if id_producto_1[0] == nombre_producto_1[0] and id_producto_1[2] == categorias[1]:
          nombres = [nombre_producto_1[1],id_producto_1[0]]
          busqueda_id_1.append(nombres)

    print("\nPara la categoría de: ", categorias[1],"\n")

    for indice_2 in range(0,7):
      print ("~",busqueda_id_1[indice_2][0])

    for id_producto_2 in menores_busquedas:
      for nombre_producto_2 in lifestore_products:
        if id_producto_2[0] == nombre_producto_2[0] and id_producto_2[2] == categorias[2]:
          nombres = [nombre_producto_2[1],id_producto_2[0]]
          busqueda_id_2.append(nombres)

    print("\nPara la categoría de: ", categorias[2],"\n")

    for indice_2 in range(0,7):
      print ("~",busqueda_id_2[indice_2][0])

    for id_producto_3 in menores_busquedas:
      for nombre_producto_3 in lifestore_products:
        if id_producto_3[0] == nombre_producto_3[0] and id_producto_3[2] == categorias[3]:
          nombres = [nombre_producto_3[1],id_producto_3[0]]
          busqueda_id_3.append(nombres)

    print("\nPara la categoría de: ", categorias[3],"\n")

    for indice_2 in range(0,7):
      print ("~",busqueda_id_3[indice_2][0])

    for id_producto_4 in menores_busquedas:
      for nombre_producto_4 in lifestore_products:
        if id_producto_4[0] == nombre_producto_4[0] and id_producto_4[2] == categorias[4]:
          nombres = [nombre_producto_4[1],id_producto_4[0]]
          busqueda_id_4.append(nombres)

    print("\nPara la categoría de: ", categorias[4],"\n")

    for indice_2 in range(0,2):
      print ("~",busqueda_id_4[indice_2][0])

    for id_producto_5 in menores_busquedas:
      for nombre_producto_5 in lifestore_products:
        if id_producto_5[0] == nombre_producto_5[0] and id_producto_5[2] == categorias[5]:
          nombres = [nombre_producto_5[1],id_producto_5[0]]
          busqueda_id_5.append(nombres)

    print("\nPara la categoría de: ", categorias[5],"\n")

    for indice_2 in range(0,7):
      print ("~",busqueda_id_5[indice_2][0])

    for id_producto_6 in menores_busquedas:
      for nombre_producto_6 in lifestore_products:
        if id_producto_6[0] == nombre_producto_6[0] and id_producto_6[2] == categorias[6]:
          nombres = [nombre_producto_6[1],id_producto_6[0]]
          busqueda_id_6.append(nombres)

    print("\nPara la categoría de: ", categorias[6],"\n")

    for indice_2 in range(0,7):
      print ("~",busqueda_id_6[indice_2][0])

    for id_producto_7 in menores_busquedas:
      for nombre_producto_7 in lifestore_products:
        if id_producto_7[0] == nombre_producto_7[0] and id_producto_7[2] == categorias[7]:
          nombres = [nombre_producto_7[1],id_producto_7[0]]
          busqueda_id_7.append(nombres)

    print("\nPara la categoría de: ", categorias[7],"\n")

    for indice_2 in range(0,7):
      print ("~",busqueda_id_7[indice_2][0])

#PRODUCTOS CON MEJORES RESEÑAS 
  if respuesta == "5":
    contador = 0
    suma_score = 0
    productos_promedio = [] 
    for producto in lifestore_products:
      for venta in lifestore_sales:
        if producto[0] == venta[1]:
          contador += 1
          suma_score += venta[2]
      promedio = suma_score / contador
      final = [producto[0], producto[1], promedio]
      productos_promedio.append(final)

      #Lista productos_promedio contiene: ID + Nombre + promedio
      #print(productos_promedio)
   
    mayores_busquedas=[]

    while productos_promedio:
      maximo = productos_promedio[0][2] 
      lista_actual = productos_promedio[0]
      for busquedas in productos_promedio:
        if busquedas[2]> maximo:
          maximo = busquedas[2]
          lista_actual = busquedas
      mayores_busquedas.append(lista_actual)
      productos_promedio.remove(lista_actual)

    print("\n\tLOS 20 PRODUCTOS CON MEJORES RESEÑAS\n")
    for indice in range(0,96):
      print ("~",mayores_busquedas[indice][1])

#PEORES RESEÑAS
  if respuesta == "6":
    contador = 0
    suma_score = 0
    productos_promedio = [] 
    for producto in lifestore_products:
      for venta in lifestore_sales:
        if producto[0] == venta[1]:
          contador += 1
          suma_score += venta[2]
      promedio = suma_score / contador
      final = [producto[0], producto[1], promedio]
      productos_promedio.append(final)

      #Lista productos_promedio contiene: ID + Nombre + promedio

    #print(productos_promedio)
    
    menores_busquedas=[]

    while productos_promedio:
      minimo = productos_promedio[0][2] 
      lista_actual = productos_promedio[0]
      for busquedas in productos_promedio:
        if busquedas[2]< minimo:
          minimo = busquedas[2]
          lista_actual = busquedas
      menores_busquedas.append(lista_actual)
      productos_promedio.remove(lista_actual)

    print("\n\tLOS 20 PRODUCTOS CON PEORES RESEÑAS\n")
    for indice in range(0,20):
      print ("~",menores_busquedas[indice][1])


""""
  elif respuesta == "7":
    print("\n\t\t≧０≦ o(╥﹏╥)o //(ㄒoㄒ)// {{{(>_<}}}")
    print("\n\t¡LO SENTIMOS! Esta información no se encuentra disponible en el programa. Por favor ve al documento 'Reporte final' para encontrar las respuestas.")
    print("\n\t\nMis más sinceras dísculpas.")
    print("\n\t\t≧０≦ o(╥﹏╥)o //(ㄒoㄒ)// {{{(>_<}}}")
 

"""


  
  